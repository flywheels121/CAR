#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "stm32f4xx_conf.h"
#include "sys.h" 

#define UART_REC_LEN 26
extern u8 UART_RX_BUF[UART_REC_LEN];
extern u8 UART_RX_STA;
#define USART_REC_LEN  			200  	//�����������ֽ��� 200
#define EN_USART5_RX 			1		//ʹ�ܣ�1��/��ֹ��0������1����




// SBUS.h
#ifndef _SBUS_H
#define _SBUS_H

#ifdef __cplusplus
 extern "C" {
#endif
	 

#include "stdio.h"	
#include "stm32f4xx_conf.h"
#include "sys.h" 
#include "stdbool.h" 

void SBUS_init(void);		
void uart_init(u32 bound);	 

#ifdef __cplusplus
 }
#endif

#endif






//void uart5_init(void);

//void uart3_init(u32 bound);
//void uart_init(u32 bound);
//u8 click_RC (void);
//void USART_TX(void);
//void DMA_Config(void);
//void usart5_send(u8 data);

//void USART5_SendByte(uint8_t byte);
//uint8_t USART5_ReceiveByte(void);

//void USART5_IRQHandler(void);
#endif


