#ifndef __LED_H
#define	__LED_H

#include "stm32f4xx.h"

//λ������,ʵ��51���Ƶ�GPIO���ƹ���
//����ʵ��˼��,�ο�<<CM3Ȩ��ָ��>>������(87ҳ~92ҳ).M4ͬM3����,ֻ�ǼĴ�����ַ����.
//IO�ڲ����궨��
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 
//IO�ڵ�ַӳ��
#define GPIOA_ODR_Addr    (GPIOA_BASE+20) //0x40020014
#define GPIOB_ODR_Addr    (GPIOB_BASE+20) //0x40020414 
#define GPIOC_ODR_Addr    (GPIOC_BASE+20) //0x40020814 
#define GPIOD_ODR_Addr    (GPIOD_BASE+20) //0x40020C14 
#define GPIOE_ODR_Addr    (GPIOE_BASE+20) //0x40021014 
#define GPIOF_ODR_Addr    (GPIOF_BASE+20) //0x40021414    
#define GPIOG_ODR_Addr    (GPIOG_BASE+20) //0x40021814   
#define GPIOH_ODR_Addr    (GPIOH_BASE+20) //0x40021C14    
#define GPIOI_ODR_Addr    (GPIOI_BASE+20) //0x40022014     

#define GPIOA_IDR_Addr    (GPIOA_BASE+16) //0x40020010 
#define GPIOB_IDR_Addr    (GPIOB_BASE+16) //0x40020410 
#define GPIOC_IDR_Addr    (GPIOC_BASE+16) //0x40020810 
#define GPIOD_IDR_Addr    (GPIOD_BASE+16) //0x40020C10 
#define GPIOE_IDR_Addr    (GPIOE_BASE+16) //0x40021010 
#define GPIOF_IDR_Addr    (GPIOF_BASE+16) //0x40021410 
#define GPIOG_IDR_Addr    (GPIOG_BASE+16) //0x40021810 
#define GPIOH_IDR_Addr    (GPIOH_BASE+16) //0x40021C10 
#define GPIOI_IDR_Addr    (GPIOI_BASE+16) //0x40022010 
 
//IO�ڲ���,ֻ�Ե�һ��IO��!
//ȷ��n��ֵС��16!
#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  //��� 
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n)  //���� 

#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)  //��� 
#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n)  //���� 

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr,n)  //��� 
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr,n)  //���� 

#define PDout(n)   BIT_ADDR(GPIOD_ODR_Addr,n)  //��� 
#define PDin(n)    BIT_ADDR(GPIOD_IDR_Addr,n)  //���� 

#define PEout(n)   BIT_ADDR(GPIOE_ODR_Addr,n)  //��� 
#define PEin(n)    BIT_ADDR(GPIOE_IDR_Addr,n)  //����

#define PFout(n)   BIT_ADDR(GPIOF_ODR_Addr,n)  //��� 
#define PFin(n)    BIT_ADDR(GPIOF_IDR_Addr,n)  //����

#define PGout(n)   BIT_ADDR(GPIOG_ODR_Addr,n)  //��� 
#define PGin(n)    BIT_ADDR(GPIOG_IDR_Addr,n)  //����

#define PHout(n)   BIT_ADDR(GPIOH_ODR_Addr,n)  //��� 
#define PHin(n)    BIT_ADDR(GPIOH_IDR_Addr,n)  //����

#define PIout(n)   BIT_ADDR(GPIOI_ODR_Addr,n)  //��� 
#define PIin(n)    BIT_ADDR(GPIOI_IDR_Addr,n)  //����



//#include "system.h"

/*--------Motor_A control pins--------*/
#define PWM_PORTA GPIOC			 //PWMA
#define PWM_PIN_A GPIO_Pin_9//PWMA
#define PWMA 	  TIM8->CCR4	 //PWMA

#define IN1_PORTA GPIOB			 //AIN1
#define IN1_PIN_A GPIO_Pin_13 //AIN1
#define AIN1 	  PBout(13)		 //AIN1

#define IN2_PORTA GPIOB			 //AIN2
#define IN2_PIN_A GPIO_Pin_12 //AIN2
#define AIN2 	  PBout(12)		 //AIN2
/*------------------------------------*/

/*--------Motor_B control pins--------*/
#define PWM_PORTB GPIOC			 //PWMB
#define PWM_PIN_B GPIO_Pin_8 //PWMB
#define PWMB 	  TIM8->CCR3	 //PWMB

#define IN1_PORTB GPIOC			 //BIN1
#define IN1_PIN_B GPIO_Pin_0 //BIN1
#define BIN1 	  PCout(0)		 //BIN1

#define IN2_PORTB GPIOB			 //BIN2
#define IN2_PIN_B GPIO_Pin_14 //BIN2
#define BIN2 	  PBout(14)		 //BIN2
/*------------------------------------*/

/*--------Motor_C control pins--------*/
#define PWM_PORTC GPIOC			 //PWMC
#define PWM_PIN_C GPIO_Pin_7 //PWMC
#define PWMC 	  TIM8->CCR2	 //PWMC

#define IN1_PORTC GPIOD			  //CIN1
#define IN1_PIN_C GPIO_Pin_10	//CIN1
#define CIN1 	  PDout(10)		  //CIN1

#define IN2_PORTC GPIOD			 //CIN2
#define IN2_PIN_C GPIO_Pin_12 //CIN2
#define CIN2 	  PDout(12)		 //CIN2
/*------------------------------------*/

/*--------Motor_D control pins--------*/
#define PWM_PORTD GPIOC			 //PWMD
#define PWMD 	  TIM8->CCR1	 //PWMD
#define PWM_PIN_D GPIO_Pin_6 //PWMD

#define IN1_PORTD GPIOC			  //DIN1
#define IN1_PIN_D GPIO_Pin_12	//DIN1
#define DIN1 	  PCout(12)		  //DIN1

#define IN2_PORTD GPIOA			  //DIN2
#define IN2_PIN_D GPIO_Pin_8	//DIN2
#define DIN2 	  PAout(8)		  //DIN2


/*------------------------------------*/
#define EN     PEin(4)  
#define Servo_PWM  TIM9->CCR1
#define Servo_PWM1  TIM4->CCR2
//#define SERVO_INIT 1500  //Servo zero point //������



//���Ŷ���
/*******************************************************/
//R ��ɫ��
#define LED1_PIN                  GPIO_Pin_13                 
#define LED1_GPIO_PORT            GPIOD                      
#define LED1_GPIO_CLK             RCC_AHB1Periph_GPIOD

//G ��ɫ��
#define LED2_PIN                  GPIO_Pin_14                 
#define LED2_GPIO_PORT            GPIOD                      
#define LED2_GPIO_CLK             RCC_AHB1Periph_GPIOD

//B ��ɫ��
#define LED3_PIN                  GPIO_Pin_15                 
#define LED3_GPIO_PORT            GPIOD                       
#define LED3_GPIO_CLK             RCC_AHB1Periph_GPIOD
/************************************************************/


/** ����LED������ĺ꣬
	* LED�͵�ƽ��������ON=0��OFF=1
	* ��LED�ߵ�ƽ�����Ѻ����ó�ON=1 ��OFF=0 ����
	*/
#define ON  0
#define OFF 1

/* ���κ꣬��������������һ��ʹ�� */
#define LED1(a)	if (a)	\
					GPIO_SetBits(LED1_GPIO_PORT,LED1_PIN);\
					else		\
					GPIO_ResetBits(LED1_GPIO_PORT,LED1_PIN)

#define LED2(a)	if (a)	\
					GPIO_SetBits(LED2_GPIO_PORT,LED2_PIN);\
					else		\
					GPIO_ResetBits(LED2_GPIO_PORT,LED2_PIN)

#define LED3(a)	if (a)	\
					GPIO_SetBits(LED3_GPIO_PORT,LED3_PIN);\
					else		\
					GPIO_ResetBits(LED3_GPIO_PORT,LED3_PIN)


/* ֱ�Ӳ����Ĵ����ķ�������IO */
#define	digitalHi(p,i)			 {p->BSRRL=i;}		//����Ϊ�ߵ�ƽ
#define digitalLo(p,i)			 {p->BSRRH=i;}		//����͵�ƽ
#define digitalToggle(p,i)	 {p->ODR ^=i;}		//�����ת״̬

/* �������IO�ĺ� */
#define LED1_TOGGLE		digitalToggle(LED1_GPIO_PORT,LED1_PIN)
#define LED1_OFF			digitalHi(LED1_GPIO_PORT,LED1_PIN)
#define LED1_ON				digitalLo(LED1_GPIO_PORT,LED1_PIN)

#define LED2_TOGGLE		digitalToggle(LED2_GPIO_PORT,LED2_PIN)
#define LED2_OFF			digitalHi(LED2_GPIO_PORT,LED2_PIN)
#define LED2_ON				digitalLo(LED2_GPIO_PORT,LED2_PIN)

#define LED3_TOGGLE		digitalToggle(LED3_GPIO_PORT,LED3_PIN)
#define LED3_OFF			digitalHi(LED3_GPIO_PORT,LED3_PIN)
#define LED3_ON				digitalLo(LED3_GPIO_PORT,LED3_PIN)

/* ������ɫ������߼��÷�ʹ��PWM�ɻ��ȫ����ɫ,��Ч������ */

//��
#define LED_RED  \
					LED1_ON;\
					LED2_OFF;\
					LED3_OFF

//��
#define LED_GREEN		\
					LED1_OFF;\
					LED2_ON;\
					LED3_OFF

//��
#define LED_BLUE	\
					LED1_OFF;\
					LED2_OFF;\
					LED3_ON

					
//��(��+��)					
#define LED_YELLOW	\
					LED1_ON;\
					LED2_ON;\
					LED3_OFF
//��(��+��)
#define LED_PURPLE	\
					LED1_ON;\
					LED2_OFF;\
					LED3_ON

//��(��+��)
#define LED_CYAN \
					LED1_OFF;\
					LED2_ON;\
					LED3_ON
					
//��(��+��+��)
#define LED_WHITE	\
					LED1_ON;\
					LED2_ON;\
					LED3_ON
					
//��(ȫ���ر�)
#define LED_RGBOFF	\
					LED1_OFF;\
					LED2_OFF;\
					LED3_OFF		



//����Ϊ��ຯ��
void WFI_SET(void);		//ִ��WFIָ��
void INTX_DISABLE(void);//�ر������ж�
void INTX_ENABLE(void);	//���������ж�
void MSR_MSP(u32 addr);	//���ö�ջ��ַ 
void Enable_Pin(void);
void MiniBalance_PWM_Init(u16 arr,u16 psc);
void MiniBalance_Motor_Init(void);
void Servo_PWM_Init(u16 arr,u16 psc);
void Servo_PWM_Init1(u16 arr,u16 psc);
void Set_Pwm(int motor_a,int motor_b,int motor_c,int motor_d,int servo);
void LED_GPIO_Config(void);

#endif /* __LED_H */


